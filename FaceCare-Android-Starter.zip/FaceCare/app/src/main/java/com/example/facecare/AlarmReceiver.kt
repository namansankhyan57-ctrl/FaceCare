package com.example.facecare

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) { fire(context) }
    companion object {
        fun fire(context: Context) {
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel("facecare_alarm", "FaceCare alarm", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
                enableVibration(true)
            }
            nm.createNotificationChannel(channel)
            val open = PendingIntent.getActivity(context, 1, Intent(context, AlarmActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val stop = PendingIntent.getBroadcast(context, 2, Intent(context, AlarmActionReceiver::class.java).setAction("STOP"), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val snooze = PendingIntent.getBroadcast(context, 3, Intent(context, AlarmActionReceiver::class.java).setAction("SNOOZE"), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(context, "facecare_alarm")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("Wash your face!")
                .setContentText("Time for your night skincare routine.")
                .setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX)
                .setFullScreenIntent(open, true).setContentIntent(open).setAutoCancel(false)
                .addAction(0, "Snooze 5 min", snooze).addAction(0, "Stop", stop).build()
            nm.notify(22, n)
            val v = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 500, 300, 500), 0)) else @Suppress("DEPRECATION") v.vibrate(longArrayOf(0, 500, 300, 500), 0)
        }
    }
}

class AlarmActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.cancel(22)
        val v = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        v.cancel()
        if (intent?.action == "SNOOZE") {
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val fireIntent = Intent(context, AlarmReceiver::class.java)
            val pi = PendingIntent.getBroadcast(context, 22, fireIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 5 * 60 * 1000L, pi)
        }
    }
}
