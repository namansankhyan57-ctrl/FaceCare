package com.example.facecare

import android.app.*
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.os.SystemClock
import java.util.Calendar

class MonitorService : Service() {
    private var lastAlarmScheduledFor = 0L
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            try {
                val now = System.currentTimeMillis()
                val cal = Calendar.getInstance()
                val afterEleven = cal.get(Calendar.HOUR_OF_DAY) >= 23
                if (afterEleven) {
                    val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
                    val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, now - 24L*60*60*1000, now)
                    val lastUse = stats?.filter { it.packageName != packageName }?.maxOfOrNull { it.lastTimeUsed } ?: now
                    val idleMs = now - lastUse
                    if (idleMs >= 15L*60*1000 && now - lastAlarmScheduledFor > 10L*60*1000) {
                        lastAlarmScheduledFor = now
                        AlarmReceiver.fire(this@MonitorService)
                    }
                }
            } catch (_: Exception) { }
            handler.postDelayed(this, 60_000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val channel = NotificationChannel("monitor", "FaceCare monitoring", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        val n = Notification.Builder(this, "monitor")
            .setContentTitle("FaceCare is monitoring")
            .setContentText("After 11 PM, checking for 15 minutes of inactivity")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).build()
        startForeground(1, n)
        handler.post(tick)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onDestroy() { handler.removeCallbacks(tick); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
