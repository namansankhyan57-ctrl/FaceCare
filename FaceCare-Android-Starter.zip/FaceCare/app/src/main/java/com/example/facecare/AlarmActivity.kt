package com.example.facecare

import android.app.Activity
import android.app.NotificationManager
import android.os.Bundle
import android.content.Intent
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.widget.*
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Vibrator
import android.view.Gravity

class AlarmActivity : Activity() {
    private var ringtone: Ringtone? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ringtone = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
        if (android.os.Build.VERSION.SDK_INT >= 28) ringtone?.isLooping = true
        ringtone?.play()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(32,32,32,32) }
        box.addView(TextView(this).apply { text = "🌙 Wash your face!\n\nTime for your night skincare routine."; textSize = 26f; gravity = Gravity.CENTER })
        box.addView(Button(this).apply { text = "Snooze 5 minutes"; setOnClickListener { stopAlarm(); sendBroadcast(Intent(this@AlarmActivity, AlarmActionReceiver::class.java).setAction("SNOOZE")); (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(22); finish() } })
        box.addView(Button(this).apply { text = "Stop"; setOnClickListener { stopAlarm(); sendBroadcast(Intent(this@AlarmActivity, AlarmActionReceiver::class.java).setAction("STOP")); (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).cancel(22); finish() } })
        setContentView(box)
    }
    private fun stopAlarm() { ringtone?.stop(); (getSystemService(VIBRATOR_SERVICE) as Vibrator).cancel() }
    override fun onDestroy() { ringtone?.stop(); super.onDestroy() }
}
