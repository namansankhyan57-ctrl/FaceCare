package com.example.facecare

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(36, 48, 36, 48)
        }
        layout.addView(TextView(this).apply {
            text = "FaceCare 🌙\n\nStarts monitoring after 11:00 PM. If no phone activity is detected for 15 minutes, it plays a normal alarm with Stop and Snooze controls."
            textSize = 20f; gravity = Gravity.CENTER
        })
        layout.addView(Button(this).apply {
            text = "Grant usage access"
            setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "Start FaceCare monitoring"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 9)
                val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
                val mode = if (Build.VERSION.SDK_INT >= 29) ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName) else ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
                if (mode == AppOpsManager.MODE_ALLOWED) {
                    val i = Intent(this, MonitorService::class.java)
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                } else startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
        })
        layout.addView(TextView(this).apply {
            text = "Setup note: allow Usage Access and notifications. For better reliability on Xiaomi/Redmi, allow background/autostart and set battery usage to No restrictions."
            textSize = 14f; setPadding(0, 24, 0, 0)
        })
        setContentView(layout)
    }
}
