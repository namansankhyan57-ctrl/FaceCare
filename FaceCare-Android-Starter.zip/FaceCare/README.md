# FaceCare Android starter project

This is an Android Studio project source (not a precompiled APK). It is configured for Android phones and tablets.

## Intended behaviour
- Monitoring window begins at 11:00 PM local device time.
- Uses Android Usage Access to estimate last app activity.
- After 15 minutes without recorded app activity, posts an alarm-priority notification and opens an alarm screen with a normal alarm ringtone, vibration, Stop and Snooze controls.
- Snooze is intended to be 5 minutes.

## Build
1. Open this folder in Android Studio (recent version with Android Gradle Plugin 8.7.3 support).
2. Let Gradle sync and install the Android SDK platform 35 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Required setup on each device
1. Open FaceCare and tap **Grant usage access**; enable FaceCare in Usage Access settings.
2. Allow notifications when prompted.
3. Return to FaceCare and tap **Start FaceCare monitoring**.
4. On Xiaomi/Redmi devices, allow Auto-start and set battery use to **No restrictions** if available.
5. Pair the Redmi Watch Move in Mi Fitness and enable app notifications for FaceCare (if Mi Fitness exposes per-app notification controls).

## Important limitations / testing
- Android's UsageStats data is an estimate of app activity, not a guaranteed record of every tap. Device-specific power management can delay or stop background work.
- The user must explicitly grant Usage Access and notification permission. Do not grant these to apps you do not trust.
- Android versions and OEM policies differ. Full-screen alarm display may be restricted unless the system permits it; the alarm notification remains the fallback.
- This starter project has not been compiled or tested on a physical Redmi device in this environment. Verify behaviour on-device before relying on it.
- The watch receives the phone's notification through its paired companion app; watch-side sound/vibration depends on watch settings and firmware.
